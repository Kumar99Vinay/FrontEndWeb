package bankApp;

public class Update extends Register {
	public void Updation() {
//		Update up = new Update();
		
	}
}